public class Linia {
    private int id;
    private Punt punt1;
    private Punt punt2;

    public Linia(int id, Punt punt1, Punt punt2) {
        this.id = id;
        this.punt1 = punt1;
        this.punt2 = punt2;
    }

    public Linia(int id, Punt[] punts) {
        if (punts.length != 2) {
            System.out.println("Una línia necessita exactament 2 punts.");
        }
        this.id = id;
        this.punt1 = punts[0];
        this.punt2 = punts[1];
    }

    public int getId() {
        return id;
    }

    public Punt getPunt1() {
        return punt1;
    }

    public Punt getPunt2() {
        return punt2;
    }

    @Override
    public String toString() {
        return "Linia{id=" + id + ", punt1=" + punt1 + ", punt2=" + punt2 + '}';
    }
}
