package org.example;

public class EmpleadoBR {
    public static float calculaSalarioBruto(TipoEmpleado tipus, float ventasMes, float horasExtra) {
        if (tipus == null || ventasMes < 0 || horasExtra < 0) {
            return -1;
        }

        float salarioBase = (tipus == TipoEmpleado.venedor) ? 1000 : 1500;

        if (ventasMes >= 1500) {
            salarioBase += 200;
        } else if (ventasMes >= 1000) {
            salarioBase += 100;
        }

        salarioBase += horasExtra * 20;

        return salarioBase;
    }

    public static float calculaSalarioNeto(float salarioBruto) {
        if (salarioBruto < 0) {
            return -1;
        }
        if (salarioBruto < 1000) {
            return salarioBruto;
        }
        if (salarioBruto < 1500) {
            return salarioBruto * 0.84f;
        }
        return salarioBruto * 0.82f;
    }
}
