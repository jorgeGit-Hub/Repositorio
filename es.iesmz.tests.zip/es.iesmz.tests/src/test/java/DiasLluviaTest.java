import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class DiasLluviaTest {
    @Test
    public void testRegistroDia() {
        DiasLluvia dl = new DiasLluvia();
        assertTrue(dl.registroDia(5, 3, true));
        assertTrue(dl.registroDia(10, 6, false));
        assertFalse(dl.registroDia(32, 1, true));
    }

    @Test
    public void testConsultarDia() {
        DiasLluvia dl = new DiasLluvia();
        dl.registroDia(5, 3, true);
        dl.registroDia(10, 6, false);
        assertTrue(dl.consultarDia(5, 3));
        assertFalse(dl.consultarDia(10, 6));
        assertNotEquals(true, dl.consultarDia(15, 4));
    }

    @Test
    public void testContarDiasLluviosos() {
        DiasLluvia dl = new DiasLluvia();
        dl.registroDia(5, 3, true);
        dl.registroDia(10, 6, true);
        assertEquals(2, dl.contarDiasLluviosos());
        dl.registroDia(15, 7, true);
        assertEquals(3, dl.contarDiasLluviosos());
        assertNotEquals(4, dl.contarDiasLluviosos());
    }

    @Test
    public void testTrimestreLluvioso() {
        DiasLluvia dl = new DiasLluvia();
        dl.registroDia(5, 1, true);
        dl.registroDia(10, 2, true);
        dl.registroDia(15, 3, true);
        assertEquals(1, dl.trimestreLluvioso());
        dl.registroDia(20, 5, true);
        assertNotEquals(3, dl.trimestreLluvioso());
    }

    @Test
    public void testPrimerDiaLluvia() {
        DiasLluvia dl = new DiasLluvia();
        assertEquals(-1, dl.primerDiaLluvia());
        dl.registroDia(5, 3, true);
        assertEquals(64, dl.primerDiaLluvia());
        dl.registroDia(2, 1, true);
        assertNotEquals(64, dl.primerDiaLluvia());
    }
}