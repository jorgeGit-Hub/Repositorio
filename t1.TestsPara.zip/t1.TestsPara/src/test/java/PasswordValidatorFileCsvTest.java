import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvFileSource;

public class PasswordValidatorFileCsvTest {

    @ParameterizedTest
    @CsvFileSource(resources = "/passwords.csv", numLinesToSkip = 1)
    void testPasswordFromFile(String password, boolean expected) {
        assertEquals(expected, PasswordValidator.isValid(password));
    }
}
