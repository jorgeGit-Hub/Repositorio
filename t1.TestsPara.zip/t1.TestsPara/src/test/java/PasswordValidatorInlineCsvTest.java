import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;

public class PasswordValidatorInlineCsvTest {

    @ParameterizedTest
    @CsvSource({
            "Password1@, true",
            "password, false",
            "PASSWORD1, false",
            "Pass1, false",
            "Password!, false",
            "Valid123$, true",
            "'', false"
    })
    void testPasswordValidity(String password, boolean expected) {
        assertEquals(expected, PasswordValidator.isValid(password));
    }
}
