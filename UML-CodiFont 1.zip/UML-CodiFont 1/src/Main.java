public class Main {
    public static void main(String[] args) {
        Punt p1 = new Punt(1, 0, 0);
        Punt p2 = new Punt(2, 1, 1);
        Punt p3 = new Punt(3, 2, 0);
        Punt p4 = new Punt(4, 3, 3);

        Linia linia1 = new Linia(1, p1, p2);
        Linia linia2 = new Linia(2, new Punt[]{p3, p4});

        Area area1 = new Area(1, new Punt[]{p1, p2, p3});
        Area area2 = new Area(2, new Punt[]{p1, p2, p3, p4});

        System.out.println(linia1);
        System.out.println(linia2);
        System.out.println(area1);
        System.out.println(area2);
    }
}
