public class DiasLluvia {
    private boolean[][] diasLluviosos;

    public DiasLluvia() {
        diasLluviosos = new boolean[12][31];
    }

    public boolean registroDia(int dia, int mes, boolean lluvia) {
        if (mes < 1 || mes > 12 || dia < 1 || dia > 31) {
            return false;
        }
        diasLluviosos[mes - 1][dia - 1] = lluvia;
        return true;
    }

    public boolean consultarDia(int dia, int mes) {
        if (mes < 1 || mes > 12 || dia < 1 || dia > 31) {
            return false;
        }
        return diasLluviosos[mes - 1][dia - 1];
    }

    public int contarDiasLluviosos() {
        int count = 0;
        for (boolean[] mes : diasLluviosos) {
            for (boolean dia : mes) {
                if (dia) {
                    count++;
                }
            }
        }
        return count;
    }

    public int trimestreLluvioso() {
        int[] trimestres = new int[4];
        int[][] limites = {{0, 2}, {3, 5}, {6, 8}, {9, 11}};
        for (int i = 0; i < 4; i++) {
            for (int mes = limites[i][0]; mes <= limites[i][1]; mes++) {
                for (boolean dia : diasLluviosos[mes]) {
                    if (dia) {
                        trimestres[i]++;
                    }
                }
            }
        }
        int maxTrimestre = 0;
        for (int i = 1; i < 4; i++) {
            if (trimestres[i] > trimestres[maxTrimestre]) {
                maxTrimestre = i;
            }
        }
        return maxTrimestre + 1;
    }

    public int primerDiaLluvia() {
        int diaContador = 1;
        for (boolean[] mes : diasLluviosos) {
            for (boolean dia : mes) {
                if (dia) {
                    return diaContador;
                }
                diaContador++;
            }
        }
        return -1;
    }
}


