package org.example;

public enum TipoEmpleado {
    venedor, encarregat;

}
