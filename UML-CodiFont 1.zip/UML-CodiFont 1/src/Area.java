import java.util.Arrays;

public class Area {
    private int id;
    private Punt[] punts;

    public Area(int id, Punt[] punts) {
        if (punts.length < 3) {
            System.out.println("Una àrea necessita almenys 3 punts.");
        }
        this.id = id;
        this.punts = punts;
    }

    public int getId() {
        return id;
    }

    public Punt[] getPunts() {
        return punts;
    }

    @Override
    public String toString() {
        return "Area{" +
                "id=" + id +
                ", punts=" + Arrays.toString(punts) +
                '}';
    }
}